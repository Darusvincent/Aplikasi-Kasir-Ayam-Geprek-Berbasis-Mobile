package com.example.aplikasi_kasir

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
